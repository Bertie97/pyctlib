#! python3.8 -u
#  -*- coding: utf-8 -*-

##############################
## Project PyCTLib
## Package visual
##############################

__all__ = """
""".split()

try: import tqdm
except ImportError:
    raise ImportError("'pyctlib.watch.debugger' cannot be used without dependency 'tqdm'. ")

def main():
    pass

if __name__ == "__main__": main()